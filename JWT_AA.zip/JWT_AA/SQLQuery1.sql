create database jwtdb;

use jwtdb;

select * from users;
select * from UserRoles;
select * from roles;