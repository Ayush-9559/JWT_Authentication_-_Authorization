﻿using JWT_AA.Models;
using Microsoft.EntityFrameworkCore;

namespace JWT_AA.Context
{
    public class JwtContext : DbContext
    {
        public JwtContext(DbContextOptions<JwtContext> options): base(options) 
        {
            
        }

        public DbSet<User> users { get; set; }

        public DbSet<Role> roles { get; set; }

        public DbSet<UserRole> UserRoles { get; set; }

        public DbSet<Employee> Employees { get; set; }
    }
}
