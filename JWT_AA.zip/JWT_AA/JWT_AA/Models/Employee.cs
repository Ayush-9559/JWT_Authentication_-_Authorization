﻿namespace JWT_AA.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Company { get; set; }
        public string Position { get; set; }
    }
}
